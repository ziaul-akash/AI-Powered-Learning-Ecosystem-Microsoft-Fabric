<h1 align="center">🎓 Learning Management System Data Platform</h1>

<p align="center">
  <b>Microsoft Fabric | ADLS Gen2 | Lakehouse | Medallion Architecture | Azure DevOps | CI/CD</b>
</p>

<h2>📌 Project Overview</h2>

<p>
This project implements an end-to-end <b>Learning Management System (LMS) data platform</b> using 
<b>Microsoft Fabric</b>. The solution ingests raw LMS data from <b>Azure Data Lake Storage Gen2 (ADLS Gen2)</b>, 
processes it through a <b>Medallion Architecture</b>, and produces clean, business-ready data for analytics.
</p>

<h2>🎯 Problem Solved</h2>

<p>The project was designed to address common data engineering challenges such as:</p>

<ul>
  <li>Managing large volumes of raw LMS data.</li>
  <li>Efficiently processing new and modified data.</li>
  <li>Improving data quality and consistency.</li>
  <li>Separating raw, cleansed and business-ready data.</li>
  <li>Reducing manual deployment and production risks.</li>
  <li>Maintaining version control and deployment history.</li>
</ul>

<h2>🏗️ Architecture</h2>

<pre>
LMS Source Data
      │
      ▼
ADLS Gen2 - Landing
      │
      │ Partitioned by Modified Date
      ▼
Fabric Data Pipeline
      │
      ▼
┌─────────────────────────────┐
│      Microsoft Fabric       │
│                             │
│  Bronze → Silver → Gold     │
│                             │
│  Raw → Cleansed → Business  │
│       Ready Data            │
└──────────────┬──────────────┘
               │
               ▼
        Analytics / BI

Azure DevOps Git
       │
       ▼
Development Workspace
       │
       ▼
Deployment Pipeline
       │
       ▼
Production Workspace
</pre>

<h2>☁️ Technology Stack</h2>

<ul>
  <li><b>Microsoft Fabric</b> – Data engineering and analytics platform</li>
  <li><b>ADLS Gen2</b> – Raw data landing and scalable storage</li>
  <li><b>Fabric Lakehouse</b> – Central data storage</li>
  <li><b>Data Pipelines</b> – Data ingestion and orchestration</li>
  <li><b>PySpark / Spark</b> – Data transformation</li>
  <li><b>SQL</b> – Data querying and transformation</li>
  <li><b>Azure DevOps & Git</b> – Source control and collaboration</li>
  <li><b>Deployment Pipelines</b> – Development-to-Production deployment</li>
</ul>

<h2>📥 Data Ingestion</h2>

<p>
Raw LMS data is first stored in <b>ADLS Gen2</b> within a landing folder. 
The data is partitioned using <b>Modified Date</b>, allowing the platform to efficiently identify and process 
new or changed data rather than repeatedly processing the entire dataset.
</p>

<pre>
ADLS Gen2
└── Landing
    ├── Students
    ├── Courses
    ├── Enrolments
    ├── Assessments
    └── Activity

Example:
modified_date=2026-01-01/
modified_date=2026-01-02/
modified_date=2026-01-03/
</pre>

<h2>🥉🥈🥇 Medallion Architecture</h2>

<table>
<tr>
<th>Layer</th>
<th>Purpose</th>
</tr>
<tr>
<td><b>Bronze</b></td>
<td>Stores raw ingested source data with minimal transformation.</td>
</tr>
<tr>
<td><b>Silver</b></td>
<td>Cleans, validates, deduplicates and standardises the data.</td>
</tr>
<tr>
<td><b>Gold</b></td>
<td>Contains business-ready and analytics-ready datasets.</td>
</tr>
</table>

<h2>🌿 Git & Azure DevOps</h2>

<p>
The Fabric development workspace is integrated with <b>Azure DevOps Git</b> to provide source control and 
version management for the data engineering solution.
</p>

<ul>
  <li>Track changes and maintain version history.</li>
  <li>Support collaborative development.</li>
  <li>Use branches for feature development.</li>
  <li>Provide controlled change management.</li>
</ul>

<h2>🚀 CI/CD & Deployment</h2>

<p>
A deployment pipeline was implemented to promote changes from the <b>Development workspace</b> to the 
<b>Production workspace</b>.
</p>

<pre>
Development
     │
     ▼
Git / Azure DevOps
     │
     ▼
Deployment Pipeline
     │
     ▼
Production
</pre>

<p>
This provides better environment separation, deployment consistency, traceability and reduces the risks 
associated with manual production changes.
</p>

<h2>💡 Key Benefits</h2>

<ul>
  <li><b>Scalable:</b> Designed to handle growing LMS data volumes.</li>
  <li><b>Efficient:</b> Date-based partitioning supports incremental processing.</li>
  <li><b>High Data Quality:</b> Silver layer provides cleansing and standardisation.</li>
  <li><b>Maintainable:</b> Clear separation between Bronze, Silver and Gold layers.</li>
  <li><b>Traceable:</b> Raw data is preserved in the Bronze layer.</li>
  <li><b>Collaborative:</b> Git enables controlled team development.</li>
  <li><b>Production Ready:</b> Development and Production environments are separated.</li>
  <li><b>Automated Deployment:</b> CI/CD reduces manual deployment effort.</li>
</ul>

<h2>🧠 Key Data Engineering Concepts</h2>

<p>
<b>Microsoft Fabric • ADLS Gen2 • Lakehouse • Data Pipelines • Medallion Architecture • 
Bronze/Silver/Gold • Data Partitioning • Incremental Processing • PySpark • SQL • 
Azure DevOps • Git • CI/CD • Data Transformation • Data Quality • Cloud Data Engineering</b>
</p>

<h2>🎤 Interview Summary</h2>

<p>
I built an end-to-end LMS data platform using <b>Microsoft Fabric</b>. Raw data was stored in 
<b>ADLS Gen2</b> and partitioned by modified date to support efficient incremental processing. 
A Fabric data pipeline ingested the data into a Lakehouse, where I implemented 
<b>Bronze, Silver and Gold layers</b> for raw, cleansed and business-ready data.
</p>

<p>
I also integrated <b>Azure DevOps Git</b> for source control and implemented a deployment pipeline 
to promote changes from Development to Production. The solution therefore addresses not only data 
processing and quality, but also <b>scalability, maintainability, version control and CI/CD</b>.
</p>

<h2>🔮 Future Enhancements</h2>

<ul>
  <li>Automated data quality checks</li>
  <li>Pipeline monitoring and alerting</li>
  <li>Metadata-driven ingestion</li>
  <li>Automated testing</li>
  <li>Power BI semantic model integration</li>
  <li>Enhanced data lineage and governance</li>
</ul>

<hr>

<p align="center">
  <b>Microsoft Fabric • Azure Data Engineering • Lakehouse • Medallion Architecture • CI/CD</b>
</p>
